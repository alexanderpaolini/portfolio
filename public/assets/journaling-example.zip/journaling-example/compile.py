#!/usr/bin/env python3
import os
import re
import datetime
import calendar
from collections import defaultdict

CONTENT_DIR = "./content"
TEMPLATE_FILE_MAIN = "templates/template.typ"
TEMPLATE_FILE_ENTRY = "templates/entry.typ"
OUTPUT_FILE = "content.typ"
OUTPUT_PDF = "out.pdf"

GRID_TEMPLATE = """
#grid(
  columns: 2,
  gutter: 16pt,
  {tables}
)"""

YEAR_TEMPLATE = """
== {year}

{content}"""

TABLE_TEMPLATE = """
[
  === {month_name}
  #table(
    columns: 7,
    stroke: 1pt,
    inset: 6pt,
    [Sun], [Mon], [Tue], [Wed], [Thu], [Fri], [Sat],
{rows}
  )
]"""

def parse_date_from_filename(filename: str) -> datetime.date:
    base = os.path.splitext(filename)[0]
    yy, mm, dd = base.split("-")
    return datetime.date(int("20" + yy), int(mm), int(dd))


def format_heading(date: datetime.date) -> str:
    day = date.day
    suffix = (
        "th" if 11 <= day <= 13
        else {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
    )
    return f"{date.strftime('%A, %B')} {day}{suffix}<{date.isoformat()}>"


def extract_yaml_front_matter(content: str):
    match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", content, re.DOTALL)
    if match:
        _, body = match.groups()
        props = {}
        return props, body
    return {}, content

def make_calendar_grid(dates):
    # group dates by year and month
    years = defaultdict(lambda: defaultdict(list))
    for d in dates:
        years[d.year][d.month].append(d)

    # year blocks hold all of the tables for every year
    year_blocks = []

    for year in sorted(years):
        # month tables holds all the tables for every month in a year
        month_tables = []

        for month in sorted(years[year]):
            # all dates in this month that should be linked
            month_dates = years[year][month]
            # build calendar weeks starting on sunday
            cal = calendar.Calendar(calendar.SUNDAY)

            rows = []
            for week in cal.monthdayscalendar(year, month):
                # build row with either empty cell, linked date, or plain date
                week_cells = [
                    "[]" if day == 0
                    else (
                      f"[#link(<{datetime.date(year, month, day).isoformat()}>)[{day}]]"
                      if datetime.date(year, month, day) in month_dates
                      else f"[{day}]")
                    for day in week
                ]
                # indent row nicely for table formatting
                rows.append("      " + ", ".join(week_cells) + ",")

            # fill in table template for this month
            table_code = TABLE_TEMPLATE.format(
                month_name=calendar.month_name[month],
                rows="\n".join(rows)
            )
            month_tables.append(table_code)

        # combine all month tables into a grid for the year
        year_blocks.append(
            YEAR_TEMPLATE.format(
                year=year,
                content=GRID_TEMPLATE.format(tables=",\n  ".join(month_tables))
            )
        )

    # return all year blocks joined together
    return "\n".join(year_blocks)


def main():
    pages = []
    dates = []

    # read all the files
    files = [f for f in sorted(os.listdir(CONTENT_DIR)) if f.endswith(".typ")]
    
    # populate the template
    with open(TEMPLATE_FILE_ENTRY, "r") as f:
      entry_template = f.read()

    # create the entries
    for i, fname in enumerate(files):
        with open(os.path.join(CONTENT_DIR, fname), "r") as f:
            content = f.read().strip()

        props, body = extract_yaml_front_matter(content)
        date = parse_date_from_filename(fname)
        heading = format_heading(date)
        written = props.get("dateWritten")
        
        page = entry_template[:].replace("{{HEADING}}", heading).replace("{{WRITTEN}}", written or "").replace("{{BODY}}", body)

        pages.append(page)
        dates.append(date)

    # read full template
    with open(TEMPLATE_FILE_MAIN, "r") as f:
        template = f.read()

    # add content
    filled = template.replace("{{CALENDER}}", make_calendar_grid(dates))
    filled = filled.replace("{{CONTENT}}", "\n".join(pages))

    with open(OUTPUT_FILE, "w") as f:
        f.write(filled)
        print(f"Wrote {OUTPUT_FILE}")

    os.system(f"typst compile {OUTPUT_FILE} {OUTPUT_PDF}")
    print(f"Compiled {OUTPUT_FILE} to {OUTPUT_PDF}")
    
    os.remove(OUTPUT_FILE)
    print(f"Deleted {OUTPUT_FILE}")

if __name__ == "__main__":
    main()