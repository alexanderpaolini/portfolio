#!/bin/bash
DATE=$(date +"%y-%m-%d")

mkdir -p content

FILE="content/$DATE.typ"

touch "$FILE"
echo "Created $FILE"